package com.zoro.soundboard.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zoro.soundboard.model.SoundEntity
import com.zoro.soundboard.ui.theme.*
import com.zoro.soundboard.viewmodel.SoundViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundboardScreen(
    viewModel: SoundViewModel,
    onImportFileClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showDiscordDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBlack)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Top Bar Title with Gaming Theme
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ZORO",
                            color = SilverWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "Android 13 Native Edition • Black & Silver",
                            color = SilverMuted,
                            fontSize = 11.sp
                        )
                    }

                    // Discord Mic notice button
                    IconButton(
                        onClick = { showDiscordDialog = true },
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, SilverBorder, RoundedCornerShape(8.dp))
                            .background(DarkSurfaceElevated)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Discord Microphone Notice",
                            tint = ZoroEmerald
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Master Volume Slider & Panic Stop
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurface)
                        .border(1.dp, SilverBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (uiState.masterVolume == 0f) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Master Volume",
                        tint = SilverText
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Slider(
                        value = uiState.masterVolume,
                        onValueChange = { viewModel.setMasterVolume(it) },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = ZoroEmerald,
                            activeTrackColor = ZoroEmerald,
                            inactiveTrackColor = SilverBorder
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { viewModel.stopAllSounds() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF7F1D1D),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("STOP", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Box
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search sounds...", color = SilverMuted, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SilverMuted) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = SilverMuted)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = ZoroEmerald,
                        unfocusedBorderColor = SilverBorder,
                        focusedTextColor = SilverWhite,
                        unfocusedTextColor = SilverWhite
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Filter Tabs
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(viewModel.categories) { category ->
                        val isSelected = uiState.selectedCategory == category
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    1.dp,
                                    if (isSelected) ZoroEmerald else SilverBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .background(if (isSelected) MetallicAccent else DarkSurface)
                                .clickable { viewModel.selectCategory(category) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = category,
                                color = if (isSelected) SilverWhite else SilverMuted,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onImportFileClick,
                containerColor = ZoroEmerald,
                contentColor = ObsidianBlack,
                icon = { Icon(Icons.Default.Add, contentDescription = "Import MP3/WAV") },
                text = { Text("Import Audio", fontWeight = FontWeight.Bold) }
            )
        },
        containerColor = ObsidianBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp)
        ) {
            // Discord Microhone Info Notice Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { showDiscordDialog = true },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, SilverBorder)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.WarningAmber,
                        contentDescription = null,
                        tint = ZoroEmerald,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Android Notice: Direct Discord mic injection is restricted by Android OS. Tap for details & workarounds.",
                        color = SilverText,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Grid of Sound Buttons
            if (uiState.filteredSounds.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No sounds match your filter.\nTap '+ Import Audio' to add MP3 or WAV files.",
                        color = SilverMuted,
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp, top = 4.dp)
                ) {
                    items(uiState.filteredSounds, key = { it.id }) { sound ->
                        SoundCard(
                            sound = sound,
                            isPlaying = uiState.playingSoundId == sound.id,
                            onPlayClick = { viewModel.togglePlaySound(sound) },
                            onFavoriteClick = { viewModel.toggleFavorite(sound.id) },
                            onLoopToggle = { viewModel.toggleLoop(sound.id) },
                            onVolumeChange = { viewModel.setSoundVolume(sound.id, it) },
                            onDeleteClick = if (sound.isCustom) {
                                { viewModel.deleteCustomSound(sound.id) }
                            } else null
                        )
                    }
                }
            }
        }
    }

    // Discord Microphone Modal Dialog
    if (showDiscordDialog) {
        AlertDialog(
            onDismissRequest = { showDiscordDialog = false },
            title = {
                Text(
                    "Discord Microphone Audio Injection on Android",
                    fontWeight = FontWeight.Bold,
                    color = SilverWhite,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Why Android doesn't allow direct sound injection into Discord's mic:",
                        fontWeight = FontWeight.SemiBold,
                        color = ZoroEmerald,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Security Sandbox: Unlike desktop Windows/Mac (which allow virtual audio cables like VB-Cable), Android's AudioRecord API enforces strict per-app microphone privacy via SELinux.\n" +
                               "• Rogue App Protection: Android prevents non-root apps from spoofing or injecting fake audio into the mic stream of other apps (Discord, WhatsApp, Zoom).\n\n" +
                               "Recommended Solutions for Mobile Gamers:\n" +
                               "1. Discord Bot: Invite Kenku.fm or a Soundboard bot to your server.\n" +
                               "2. Screen Share Audio: On Android 10+, Discord supports sharing internal device audio during Screen Share streams.\n" +
                               "3. Hardware Splitter: Use a standard TRRS 3.5mm gaming audio splitter cable.",
                        color = SilverText,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showDiscordDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ZoroEmerald)
                ) {
                    Text("Got It", color = ObsidianBlack, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkSurfaceElevated,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun SoundCard(
    sound: SoundEntity,
    isPlaying: Boolean,
    onPlayClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onLoopToggle: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onDeleteClick: (() -> Unit)?
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(
                1.dp,
                if (isPlaying) ZoroEmerald else SilverBorder,
                RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPlaying) MetallicActiveSurface else DarkSurface
        )
    ) {
        Column(
            modifier = Modifier.padding(10.dp)
        ) {
            // Header: Favorite and Category
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = sound.category,
                    color = SilverMuted,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = if (sound.isFavorite) Icons.Filled.Star else Icons.Outlined.Star,
                        contentDescription = "Favorite",
                        tint = if (sound.isFavorite) Color(0xFFFBBF24) else SilverMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Sound Name
            Text(
                text = sound.name,
                color = SilverWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "${String.format("%.1f", sound.durationSeconds)}s",
                color = SilverMuted,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Main Play/Stop Trigger Button
            Button(
                onClick = onPlayClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPlaying) ZoroEmerald else SilverMetallicButton,
                    contentColor = if (isPlaying) ObsidianBlack else SilverWhite
                )
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Stop" else "Play",
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isPlaying) "STOP" else "PLAY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Bottom controls: Loop toggle and volume
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Loop toggle
                IconButton(
                    onClick = onLoopToggle,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Repeat,
                        contentDescription = "Loop",
                        tint = if (sound.loop) ZoroEmerald else SilverMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }

                if (onDeleteClick != null) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
