package com.zoro.soundboard

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.zoro.soundboard.ui.SoundboardScreen
import com.zoro.soundboard.ui.theme.ZOROSoundboardTheme
import com.zoro.soundboard.viewmodel.SoundViewModel

/**
 * ZORO Soundboard - Native Android 13 App
 * Features:
 * - Black & Silver gaming theme
 * - Audio playback with volume, loop, master controls
 * - Android 13 permissions (READ_MEDIA_AUDIO, POST_NOTIFICATIONS)
 * - Safe file picker for MP3/WAV files
 * - SharedPreferences persistence
 * - Discord microphone injection advisory
 */
class MainActivity : ComponentActivity() {

    private val viewModel: SoundViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ZOROSoundboardTheme {
                // Android 13 granular media permissions launcher
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissions ->
                    val audioGranted = permissions[Manifest.permission.READ_MEDIA_AUDIO] ?: false
                    if (!audioGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Toast.makeText(
                            this,
                            "Audio permission is needed to import your MP3 and WAV files.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                // File picker launcher for importing custom MP3 / WAV files
                val filePickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri ->
                    uri?.let { viewModel.importCustomAudio(this, it) }
                }

                LaunchedEffect(Unit) {
                    // Check and request Android 13 specific permissions
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val neededPermissions = mutableListOf<String>()
                        if (ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.READ_MEDIA_AUDIO
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            neededPermissions.add(Manifest.permission.READ_MEDIA_AUDIO)
                        }
                        if (ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            neededPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        if (neededPermissions.isNotEmpty()) {
                            permissionLauncher.launch(neededPermissions.toTypedArray())
                        }
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    SoundboardScreen(
                        viewModel = viewModel,
                        onImportFileClick = {
                            filePickerLauncher.launch("audio/*")
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.releaseAudioPlayer()
    }
}
