package com.zoro.soundboard.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import com.zoro.soundboard.audio.AudioPlayerManager
import com.zoro.soundboard.model.SoundEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class SoundboardUiState(
    val sounds: List<SoundEntity> = emptyList(),
    val filteredSounds: List<SoundEntity> = emptyList(),
    val selectedCategory: String = "All",
    val searchQuery: String = "",
    val masterVolume: Float = 0.85f,
    val playingSoundId: String? = null
)

class SoundViewModel(application: Application) : AndroidViewModel(application) {

    private val audioManager = AudioPlayerManager(application)
    private val prefs = application.getSharedPreferences("zoro_soundboard_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(SoundboardUiState())
    val uiState: StateFlow<SoundboardUiState> = _uiState.asStateFlow()

    val categories = listOf(
        "All",
        "Favorites",
        "Zoro & Anime",
        "Combat & Katana",
        "Gaming SFX",
        "Memes & Horns",
        "Custom"
    )

    init {
        loadSounds()
    }

    private fun loadSounds() {
        val masterVol = prefs.getFloat("master_volume", 0.85f)
        audioManager.setMasterVolume(masterVol)

        val defaultList = listOf(
            SoundEntity("zoro_onigiri", "Santoryu: Onigiri", "Zoro & Anime", 1.2f, isFavorite = true),
            SoundEntity("zoro_shishi", "Iai: Shishi Sonson", "Zoro & Anime", 1.0f, isFavorite = true),
            SoundEntity("zoro_tatsumaki", "Dragon Twister", "Zoro & Anime", 1.8f, isFavorite = true),
            SoundEntity("zoro_asura", "Demonic Asura (9 Blades)", "Zoro & Anime", 1.6f),
            SoundEntity("zoro_nothing", "Nothing Happened", "Zoro & Anime", 2.5f, isFavorite = true),
            SoundEntity("katana_slash", "Katana Swift Slash", "Combat & Katana", 0.5f),
            SoundEntity("sheath_snap", "Steel Sheath Snap", "Combat & Katana", 0.4f),
            SoundEntity("blade_parry", "Blade Shield Deflect", "Combat & Katana", 0.8f),
            SoundEntity("crit_hit", "Critical Strike Hit", "Gaming SFX", 0.7f),
            SoundEntity("xp_levelup", "XP Level Up Chime", "Gaming SFX", 0.8f, isFavorite = true),
            SoundEntity("victory_fanfare", "Victory Fanfare", "Gaming SFX", 1.3f),
            SoundEntity("game_over", "Mission Failed Tone", "Gaming SFX", 1.1f),
            SoundEntity("sub_808", "Sub-Bass 808 Drop", "Gaming SFX", 1.5f, isFavorite = true),
            SoundEntity("airhorn_mlg", "MLG Tactical Airhorn", "Memes & Horns", 0.85f, isFavorite = true)
        )

        val customSounds = loadCustomSoundsFromPrefs()
        val combined = defaultList + customSounds

        _uiState.update {
            it.copy(
                sounds = combined,
                masterVolume = masterVol
            )
        }
        applyFilter()
    }

    fun setMasterVolume(vol: Float) {
        audioManager.setMasterVolume(vol)
        prefs.edit().putFloat("master_volume", vol).apply()
        _uiState.update { it.copy(masterVolume = vol) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        applyFilter()
    }

    fun selectCategory(cat: String) {
        _uiState.update { it.copy(selectedCategory = cat) }
        applyFilter()
    }

    fun toggleFavorite(id: String) {
        val updated = _uiState.value.sounds.map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
        _uiState.update { it.copy(sounds = updated) }
        saveCustomSoundsToPrefs(updated.filter { it.isCustom })
        applyFilter()
    }

    fun toggleLoop(id: String) {
        val updated = _uiState.value.sounds.map {
            if (it.id == id) it.copy(loop = !it.loop) else it
        }
        _uiState.update { it.copy(sounds = updated) }
    }

    fun setSoundVolume(id: String, vol: Float) {
        val updated = _uiState.value.sounds.map {
            if (it.id == id) it.copy(volume = vol) else it
        }
        _uiState.update { it.copy(sounds = updated) }
    }

    fun togglePlaySound(sound: SoundEntity) {
        if (_uiState.value.playingSoundId == sound.id) {
            audioManager.stopSound(sound.id)
            _uiState.update { it.copy(playingSoundId = null) }
        } else {
            _uiState.update { it.copy(playingSoundId = sound.id) }
            val uri = sound.fileUriString?.let { Uri.parse(it) }
            audioManager.playSound(
                id = sound.id,
                fileUri = uri,
                resId = null,
                individualVolume = sound.volume,
                loop = sound.loop,
                onCompletion = {
                    _uiState.update { state ->
                        if (state.playingSoundId == sound.id) state.copy(playingSoundId = null) else state
                    }
                }
            )
        }
    }

    fun stopAllSounds() {
        audioManager.stopAll()
        _uiState.update { it.copy(playingSoundId = null) }
    }

    fun importCustomAudio(context: Context, uri: Uri) {
        try {
            val contentResolver = context.contentResolver
            val fileName = "custom_sound_${System.currentTimeMillis()}.mp3"
            val localFile = File(context.filesDir, fileName)

            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(localFile).use { output ->
                    input.copyTo(output)
                }
            }

            val newSound = SoundEntity(
                id = "custom_${System.currentTimeMillis()}",
                name = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Imported Sound",
                category = "Custom",
                durationSeconds = 1.0f,
                isCustom = true,
                fileUriString = Uri.fromFile(localFile).toString()
            )

            val updated = _uiState.value.sounds + newSound
            _uiState.update { it.copy(sounds = updated) }
            saveCustomSoundsToPrefs(updated.filter { it.isCustom })
            applyFilter()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun deleteCustomSound(id: String) {
        audioManager.stopSound(id)
        val updated = _uiState.value.sounds.filterNot { it.id == id }
        _uiState.update { it.copy(sounds = updated) }
        saveCustomSoundsToPrefs(updated.filter { it.isCustom })
        applyFilter()
    }

    private fun applyFilter() {
        val q = _uiState.value.searchQuery.trim().lowercase()
        val cat = _uiState.value.selectedCategory

        val filtered = _uiState.value.sounds.filter { sound ->
            val matchesQuery = q.isEmpty() || sound.name.lowercase().contains(q)
            val matchesCat = when (cat) {
                "All" -> true
                "Favorites" -> sound.isFavorite
                else -> sound.category == cat
            }
            matchesQuery && matchesCat
        }

        _uiState.update { it.copy(filteredSounds = filtered) }
    }

    private fun saveCustomSoundsToPrefs(customs: List<SoundEntity>) {
        val array = JSONArray()
        customs.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("name", it.name)
            obj.put("category", it.category)
            obj.put("duration", it.durationSeconds.toDouble())
            obj.put("uri", it.fileUriString)
            obj.put("favorite", it.isFavorite)
            array.put(obj)
        }
        prefs.edit().putString("custom_sounds_json", array.toString()).apply()
    }

    private fun loadCustomSoundsFromPrefs(): List<SoundEntity> {
        val jsonStr = prefs.getString("custom_sounds_json", null) ?: return emptyList()
        val list = mutableListOf<SoundEntity>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    SoundEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        category = obj.optString("category", "Custom"),
                        durationSeconds = obj.optDouble("duration", 1.0).toFloat(),
                        isCustom = true,
                        fileUriString = obj.optString("uri", null),
                        isFavorite = obj.optBoolean("favorite", false)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun releaseAudioPlayer() {
        audioManager.release()
    }
}
