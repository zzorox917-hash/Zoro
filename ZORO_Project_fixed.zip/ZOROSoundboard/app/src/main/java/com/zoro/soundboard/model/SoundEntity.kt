package com.zoro.soundboard.model

data class SoundEntity(
    val id: String,
    val name: String,
    val category: String,
    val durationSeconds: Float = 1.0f,
    val volume: Float = 1.0f,
    val loop: Boolean = false,
    val isFavorite: Boolean = false,
    val isCustom: Boolean = false,
    val fileUriString: String? = null
)
