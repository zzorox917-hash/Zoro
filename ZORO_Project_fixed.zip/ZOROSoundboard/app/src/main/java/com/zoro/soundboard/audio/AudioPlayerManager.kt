package com.zoro.soundboard.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log

/**
 * Manages audio playback, volume scaling, looping, and resource cleanup
 * for the ZORO Soundboard native app.
 */
class AudioPlayerManager(private val context: Context) {

    private val activePlayers = mutableMapOf<String, MediaPlayer>()
    private var masterVolume: Float = 0.85f

    fun setMasterVolume(vol: Float) {
        masterVolume = vol.coerceIn(0f, 1f)
        // Adjust all active players
        activePlayers.values.forEach { player ->
            try {
                player.setVolume(masterVolume, masterVolume)
            } catch (e: Exception) {
                Log.e("AudioPlayerManager", "Failed to adjust volume", e)
            }
        }
    }

    fun playSound(
        id: String,
        fileUri: Uri?,
        resId: Int?,
        individualVolume: Float,
        loop: Boolean,
        onCompletion: () -> Unit
    ) {
        // Stop any running instance of this sound
        stopSound(id)

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .build()
                )

                if (fileUri != null) {
                    setDataSource(context, fileUri)
                } else if (resId != null) {
                    val afd = context.resources.openRawResourceFd(resId) ?: return
                    setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                } else {
                    return
                }

                val finalVolume = (individualVolume * masterVolume).coerceIn(0f, 1f)
                setVolume(finalVolume, finalVolume)
                isLooping = loop

                setOnCompletionListener {
                    if (!loop) {
                        stopSound(id)
                        onCompletion()
                    }
                }

                prepare()
                start()
            }

            activePlayers[id] = player
        } catch (e: Exception) {
            Log.e("AudioPlayerManager", "Error playing sound $id", e)
        }
    }

    fun stopSound(id: String) {
        activePlayers[id]?.let { player ->
            try {
                if (player.isPlaying) {
                    player.stop()
                }
                player.release()
            } catch (e: Exception) {
                Log.e("AudioPlayerManager", "Error stopping player $id", e)
            }
        }
        activePlayers.remove(id)
    }

    fun stopAll() {
        activePlayers.keys.toList().forEach { id ->
            stopSound(id)
        }
        activePlayers.clear()
    }

    fun isPlaying(id: String): Boolean {
        return try {
            activePlayers[id]?.isPlaying == true
        } catch (e: Exception) {
            false
        }
    }

    fun release() {
        stopAll()
    }
}
