package com.zoro.soundboard.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF0B0D12)
val DarkSurface = Color(0xFF141822)
val DarkSurfaceElevated = Color(0xFF1C2230)
val MetallicActiveSurface = Color(0xFF222B3D)
val SilverBorder = Color(0xFF333E52)
val SilverMetallicButton = Color(0xFF2B3242)
val SilverWhite = Color(0xFFF1F5F9)
val SilverText = Color(0xFFE2E8F0)
val SilverMuted = Color(0xFF94A3B8)
val ZoroEmerald = Color(0xFF10B981)
val MetallicAccent = Color(0xFF1E293B)

private val DarkColorScheme = darkColorScheme(
    primary = ZoroEmerald,
    secondary = SilverText,
    tertiary = SilverBorder,
    background = ObsidianBlack,
    surface = DarkSurface,
    onPrimary = ObsidianBlack,
    onSecondary = ObsidianBlack,
    onBackground = SilverWhite,
    onSurface = SilverWhite
)

@Composable
fun ZOROSoundboardTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
