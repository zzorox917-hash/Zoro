# ZORO Soundboard - Android 13 Build & APK Installation Guide

This document explains how to build the APK from this complete Jetpack Compose project and install it directly on your Android phone.

---

## 🛠️ Step 1: Open the Project in Android Studio

1. Download the complete project archive using the **"Download Project (.zip)"** button in the app.
2. Unzip `ZOROSoundboard.zip` to your computer (e.g. `~/AndroidStudioProjects/ZOROSoundboard`).
3. Open **Android Studio** (Hedgehog, Iguana, Jellyfish, or newer).
4. Select **File > Open...** and choose the unzipped `ZOROSoundboard` folder.
5. Wait 1–2 minutes for Gradle to sync dependencies automatically.

---

## ⚡ Step 2: Build the APK File

### Option A: Via Android Studio Menu (Easiest)
1. Go to the top menu bar in Android Studio.
2. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Once completed, a pop-up appears in the bottom right corner saying *"APK(s) generated successfully"*.
4. Click **locate** in that notification. It will open the folder containing:
   `app/build/outputs/apk/debug/app-debug.apk`

### Option B: Via Terminal / Command Line
Run this command from the root project folder:
```bash
# On Linux / macOS:
./gradlew assembleDebug

# On Windows:
gradlew.bat assembleDebug
```
The resulting APK is at `app/build/outputs/apk/debug/app-debug.apk`.

---

## 📱 Step 3: Enable Developer Options & Install on Phone

### 1. Enable Developer Options on Android 13:
1. On your phone, go to **Settings > About Phone**.
2. Scroll to **Build Number** and tap it **7 times** quickly until you see *"You are now a developer!"*.
3. Go back to **Settings > System > Developer Options**.
4. Enable **USB Debugging** (and optionally **Install via USB** if on Xiaomi/MIUI).

### 2. Install directly via USB Cable:
1. Connect phone to PC with USB cable.
2. Select your device from the device dropdown at the top of Android Studio.
3. Click the green **Run (▶)** button. The app will compile and install automatically onto your phone!

### 3. Alternative: Transfer the APK file directly to phone:
1. Copy `app-debug.apk` to your phone using USB cable, Google Drive, WhatsApp, Telegram, or LocalSend.
2. On your phone, open the **Files** app and tap `app-debug.apk`.
3. If prompted with *"For your security, your phone is not allowed to install unknown apps from this source"*, tap **Settings** and toggle **Allow from this source**.
4. Tap **Install**!

---

## 🎙️ Note Regarding Discord Microphone Injection
- Android 13 enforces strict sandbox security (`SELinux` + `AudioRecord`), which stops any non-root Android app from directly injecting sound into Discord's microphone stream.
- For voice channel soundboards on mobile, invite a Discord bot (e.g. Kenku.fm) or share device internal audio during a Discord screen share.
