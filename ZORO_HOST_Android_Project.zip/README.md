# ZORO HOST Android Starter (v0.1.0)

An Android-first Kotlin + Jetpack Compose starter for the ZORO HOST concept: Minecraft server setup and Python/Node.js bot setup, with the black/charcoal/neon-green visual style.

## Important status

This is a **buildable UI and guided-setup starter**, not a completed hosting engine. It does not claim a server or bot is running. Local Minecraft/Node/Python execution and remote deployment need an execution adapter/backend, and are deliberately marked as not connected in the UI.

### Why this limitation matters
- Standard Android apps do not automatically include Java, Python, or Node.js runtimes.
- Local execution typically requires a compatible runtime/Termux integration and explicit Android permissions.
- Android may stop long-running background processes.
- Remote mode needs a real authenticated API on a server you control. Do not send bot tokens to an untrusted backend.
- Public internet access requires a working network route or tunnel provider.

## Build using only an Android phone

### Option A: AndroidIDE
1. Install AndroidIDE from its official project/release source and follow its current installation guide.
2. Extract this ZIP to a folder accessible to AndroidIDE.
3. Open the folder containing `settings.gradle.kts`.
4. Allow Gradle to sync and download dependencies.
5. Build the `app` debug variant.
6. Install the generated debug APK from AndroidIDE's output/build panel.

### Option B: Termux + command line
A compatible JDK and Android SDK/Gradle setup is required. This can be harder on phones; AndroidIDE is generally the simpler route. Use only official project sources and review any permissions before installing tools.

## Project structure

- `settings.gradle.kts` — project modules and repositories
- `build.gradle.kts` — Android/Kotlin plugin versions
- `app/build.gradle.kts` — app configuration and Compose dependencies
- `app/src/main/AndroidManifest.xml` — app entry point and Internet permission
- `app/src/main/java/com/zoro/host/MainActivity.kt` — dashboard, guided setup, and theme

## Current features
- Home dashboard with Minecraft and Bot Hosting entry points
- 8-step setup flow
- Minecraft software/version selection
- Python/Node.js bot runtime selection
- Project file picker
- RAM configuration UI with safety note
- Local/remote/hybrid mode selection
- Clear non-simulated status messaging

## Not yet implemented
- Persistent project database
- Actual Minecraft server process/runtime management
- Actual Python/Node.js process execution
- Dependency installation sandbox
- Remote API authentication and deployment
- Real process metrics, live log streaming, secure secret vault, backup/restore
- Foreground service and crash-restart worker

Do not treat a configured setup as deployed. Those features must be implemented and tested before using the app for real hosting.
