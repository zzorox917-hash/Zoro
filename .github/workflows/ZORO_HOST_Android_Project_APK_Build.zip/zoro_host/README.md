# ZORO HOST Android Starter (v0.1.0)

An Android-first Kotlin + Jetpack Compose starter for the ZORO HOST concept: Minecraft server setup and Python/Node.js bot setup, with the black/charcoal/neon-green visual style.

## Important status

This is a **buildable UI and guided-setup starter**, not a completed hosting engine. It does not claim a server or bot is running. Local Minecraft/Node/Python execution and remote deployment need an execution adapter/backend, and are deliberately marked as not connected in the UI.

### Why this limitation matters
- Standard Android apps do not automatically include Java, Python, or Node.js runtimes.
- Local execution typically requires a compatible runtime/Termux integration and explicit Android permissions.
- Android may stop long-running background processes.
- Remote mode needs a real authenticated API on a server you control. Do not send bot tokens to an untrusted backend.
- Public internet access requires a working network route or tunnel provider.

## Build using only an Android phone

### Option A: AndroidIDE
1. Install AndroidIDE from its official project/release source and follow its current installation guide.
2. Extract this ZIP to a folder accessible to AndroidIDE.
3. Open the folder containing `settings.gradle.kts`.
4. Allow Gradle to sync and download dependencies.
5. Build the `app` debug variant.
6. Install the generated debug APK from AndroidIDE's output/build panel.

### Option B: Termux + command line
A compatible JDK and Android SDK/Gradle setup is required. This can be harder on phones; AndroidIDE is generally the simpler route. Use only official project sources and review any permissions before installing tools.

## Project structure

- `settings.gradle.kts` — project modules and repositories
- `build.gradle.kts` — Android/Kotlin plugin versions
- `app/build.gradle.kts` — app configuration and Compose dependencies
- `app/src/main/AndroidManifest.xml` — app entry point and Internet permission
- `app/src/main/java/com/zoro/host/MainActivity.kt` — dashboard, guided setup, and theme

## Current features
- Home dashboard with Minecraft and Bot Hosting entry points
- 8-step setup flow
- Minecraft software/version selection
- Python/Node.js bot runtime selection
- Project file picker
- RAM configuration UI with safety note
- Local/remote/hybrid mode selection
- Clear non-simulated status messaging

## Not yet implemented
- Persistent project database
- Actual Minecraft server process/runtime management
- Actual Python/Node.js process execution
- Dependency installation sandbox
- Remote API authentication and deployment
- Real process metrics, live log streaming, secure secret vault, backup/restore
- Foreground service and crash-restart worker

Do not treat a configured setup as deployed. Those features must be implemented and tested before using the app for real hosting.

## Build an APK with GitHub Actions

This project includes `.github/workflows/build-apk.yml`. To use it:
1. Create a GitHub repository and upload the contents of this project (not the ZIP itself).
2. Open the repository's **Actions** tab and run **Build ZORO HOST APK** (or push to `main`/`master`).
3. When the workflow succeeds, open that run and download the `ZORO-HOST-debug-apk` artifact.
4. Extract the artifact and install `app-debug.apk` on your Android device. Android may ask you to allow installation from that source.

The workflow builds the **debug APK**. It has not been executed from this environment, so the build must be verified by the workflow before installation.

## Hosting engine status — important

The current APK project is a configuration/dashboard MVP. It does **not** yet start real Minecraft servers or Python/Node.js bots. To deliver real hosting, implement and connect either (a) a server you control with an authenticated HTTPS API and process isolation, or (b) a tested on-device runtime/engine. A remote backend must keep bot credentials in a server-side secret store, enforce authentication and resource limits, and expose truthful process status/logs. Never put private bot tokens directly in the APK or source code.
