package com.zoro.host

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF111111)
private val Panel = Color(0xFF1D1D1D)
private val Green = Color(0xFF00D084)
private val Muted = Color(0xFFAAAAAA)
private val White = Color(0xFFF5F5F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZoroApp() }
    }
}

@Composable
fun ZoroApp() {
    var page by remember { mutableStateOf("Home") }
    var wizardStep by remember { mutableIntStateOf(0) }
    var hostingType by remember { mutableStateOf("Minecraft") }
    var name by remember { mutableStateOf("ZORO Server") }
    var software by remember { mutableStateOf("Paper") }
    var version by remember { mutableStateOf("1.21.10") }
    var runtime by remember { mutableStateOf("Python") }
    var ram by remember { mutableFloatStateOf(1f) }
    var mode by remember { mutableStateOf("Local (Termux required)") }
    var remoteUrl by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf("No project file selected") }
    var notice by remember { mutableStateOf("Ready to configure. No server is running yet.") }
    var setupDone by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            selectedFile = uri.lastPathSegment ?: uri.toString()
            notice = "Selected file: $selectedFile. Importing/executing projects is not wired up in this MVP."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel, onPrimary = Bg,
        onBackground = White, onSurface = White, secondary = Green
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = White) {
                    listOf("Home", "Minecraft", "Bots", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Minecraft" -> Icons.Default.SportsEsports
                                        "Bots" -> Icons.Default.SmartToy
                                        "Settings" -> Icons.Default.Settings
                                        else -> Icons.Default.Dashboard
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green, selectedTextColor = Green,
                                indicatorColor = Color(0xFF263B32),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ZORO HOST", color = White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            Text("MINECRAFT  •  BOT HOSTING", color = Green, fontSize = 11.sp, letterSpacing = 1.2.sp)
                        }
                        Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                            Text("MVP", color = Green, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                        }
                    }
                }
                when (page) {
                    "Home" -> {
                        item { Text("Your hosting workspace", color = Muted) }
                        item {
                            HostCard("Minecraft Hosting", "Java & Bedrock setup, worlds, plugins and server settings", Icons.Default.SportsEsports) {
                                hostingType = "Minecraft"; wizardStep = 0; page = "Setup"
                            }
                        }
                        item {
                            HostCard("Bot Hosting", "Python and Node.js project setup for Discord bots", Icons.Default.SmartToy) {
                                hostingType = "Bot"; wizardStep = 0; page = "Setup"
                            }
                        }
                        item {
                            PanelCard {
                                Text("Runtime status", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                StatusRow("Local engine", "Not connected", Color(0xFFFFB74D))
                                StatusRow("Remote backend", if (remoteUrl.isBlank()) "Not configured" else "URL saved in session", Muted)
                                StatusRow("Server processes", "0 verified", Muted)
                                Text("This starter app does not pretend a server is online. Connect a real local engine or remote backend before deployment.", color = Muted, fontSize = 12.sp)
                            }
                        }
                        item { Button(onClick = { page = "Settings" }, modifier = Modifier.fillMaxWidth()) { Text("Configure hosting connection") } }
                    }
                    "Minecraft" -> {
                        item { Text("Minecraft Hosting", fontSize = 23.sp, fontWeight = FontWeight.Bold) }
                        item { HostCard("Create Minecraft server", "Choose software, version, RAM and connection mode", Icons.Default.Add) {
                            hostingType = "Minecraft"; wizardStep = 0; page = "Setup"
                        } }
                        item { PanelCard {
                            Text("Execution status", fontWeight = FontWeight.Bold)
                            Text("No Minecraft process has been started by this app.", color = Muted)
                            Text("Local Java server execution needs a compatible runtime/engine. Remote execution needs a configured hosting API.", color = Muted, fontSize = 12.sp)
                        } }
                    }
                    "Bots" -> {
                        item { Text("Bot Hosting", fontSize = 23.sp, fontWeight = FontWeight.Bold) }
                        item { HostCard("Create bot project", "Python or Node.js · upload ZIP · configure environment", Icons.Default.Add) {
                            hostingType = "Bot"; wizardStep = 0; page = "Setup"
                        } }
                        item { PanelCard {
                            Text("Your bots", fontWeight = FontWeight.Bold)
                            Text("No bot projects deployed yet.", color = Muted)
                            Text("Bot execution requires a compatible local runtime such as Termux integration or a remote backend. This UI does not simulate a running bot.", color = Muted, fontSize = 12.sp)
                        } }
                    }
                    "Settings" -> {
                        item { Text("Hosting connections", fontSize = 23.sp, fontWeight = FontWeight.Bold) }
                        item { PanelCard {
                            Text("Execution mode", fontWeight = FontWeight.Bold)
                            listOf("Local (Termux required)", "Remote API", "Hybrid").forEach { option ->
                                Row(Modifier.fillMaxWidth().clickable { mode = option }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selected = mode == option, onClick = { mode = option }, colors = RadioButtonDefaults.colors(selectedColor = Green))
                                    Text(option, modifier = Modifier.padding(start = 8.dp))
                                }
                            }
                            OutlinedTextField(value = remoteUrl, onValueChange = { remoteUrl = it }, label = { Text("Remote backend HTTPS URL") }, placeholder = { Text("https://your-server.example/api") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Text("No backend URL is contacted in this MVP. Do not paste bot tokens here.", color = Muted, fontSize = 12.sp)
                            Button(onClick = { notice = "Connection choice saved for this session: $mode"; page = "Home" }, modifier = Modifier.fillMaxWidth()) { Text("Save settings") }
                        } }
                    }
                    "Setup" -> {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { if (wizardStep > 0) wizardStep-- else page = "Home" }) { Icon(Icons.Default.ArrowBack, null, tint = White) }
                                Column {
                                    Text("Guided Setup", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                    Text("STEP ${wizardStep + 1} OF 8", color = Green, fontSize = 12.sp)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                                repeat(8) { index ->
                                    Box(Modifier.weight(1f).height(4.dp).background(if (index <= wizardStep) Green else Color(0xFF383838), RoundedCornerShape(8.dp)))
                                }
                            }
                        }
                        item {
                            PanelCard {
                                when (wizardStep) {
                                    0 -> {
                                        Text("Create ${hostingType} Project", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        Text("Give your project a name.", color = Muted)
                                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Project name") }, modifier = Modifier.fillMaxWidth())
                                        if (hostingType == "Bot") {
                                            Text("Language", fontWeight = FontWeight.SemiBold)
                                            listOf("Python", "Node.js").forEach { option ->
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    RadioButton(selected = runtime == option, onClick = { runtime = option }, colors = RadioButtonDefaults.colors(selectedColor = Green))
                                                    Text(option)
                                                }
                                            }
                                        }
                                    }
                                    1 -> {
                                        Text(if (hostingType == "Minecraft") "Choose Software" else "Choose Runtime", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        Text("Select a compatible runtime. Actual availability depends on your device or remote provider.", color = Muted)
                                        if (hostingType == "Minecraft") {
                                            listOf("Paper", "Fabric", "Vanilla", "Purpur", "PowerNukkitX").forEach { option ->
                                                SelectRow(option, software == option) { software = option }
                                            }
                                        } else {
                                            listOf("Python", "Node.js").forEach { option -> SelectRow(option, runtime == option) { runtime = option } }
                                        }
                                    }
                                    2 -> {
                                        Text("Choose Version / Upload Files", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        if (hostingType == "Minecraft") {
                                            OutlinedTextField(value = version, onValueChange = { version = it }, label = { Text("Minecraft version") }, modifier = Modifier.fillMaxWidth())
                                            Text("Choose only a version supported by the selected software.", color = Muted, fontSize = 12.sp)
                                        }
                                        Text(selectedFile, color = Muted, fontSize = 13.sp)
                                        OutlinedButton(onClick = { picker.launch(arrayOf("application/zip", "application/java-archive", "text/plain", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
                                            Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("Choose project / server file")
                                        }
                                    }
                                    3 -> {
                                        Text("Allocate RAM", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        Text("${"%.1f".format(ram)} GB configured (requested value only)", color = Green, fontSize = 24.sp)
                                        Slider(value = ram, onValueChange = { ram = it }, valueRange = 0.5f..4.5f, colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                            Text("0.5 GB", color = Muted, fontSize = 12.sp); Text("4.5 GB", color = Muted, fontSize = 12.sp)
                                        }
                                        Text("This setting is not enforced until a compatible execution engine is connected. Keep RAM available for Android.", color = Color(0xFFFFB74D), fontSize = 12.sp)
                                    }
                                    4 -> {
                                        Text(if (hostingType == "Bot") "Environment & Start Command" else "Server Settings", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        Text("Set up configuration before deploying.", color = Muted)
                                        if (hostingType == "Bot") {
                                            OutlinedTextField(value = if (runtime == "Python") "python main.py" else "node index.js", onValueChange = {}, readOnly = true, label = { Text("Suggested start command") }, modifier = Modifier.fillMaxWidth())
                                            Text("Configure DISCORD_TOKEN in the runtime's secure secret store, not in source code.", color = Muted, fontSize = 12.sp)
                                        } else {
                                            SelectRow("Survival", true) {}
                                            SelectRow("Normal difficulty", true) {}
                                            SelectRow("Whitelist recommended", false) {}
                                        }
                                    }
                                    5 -> {
                                        Text("Optional Extras", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        val extras = if (hostingType == "Bot") listOf("Crash auto-restart", "Project backup", "Live logs") else listOf("Geyser cross-play (compatible servers)", "Simple Voice Chat", "World pre-generation")
                                        extras.forEach { SelectRow(it, false) { notice = "$it selected in preview; install support requires an execution engine." } }
                                    }
                                    6 -> {
                                        Text("Connect / Execution Mode", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        listOf("Local (Termux required)", "Remote API", "Hybrid").forEach { SelectRow(it, mode == it) { mode = it } }
                                        OutlinedTextField(value = remoteUrl, onValueChange = { remoteUrl = it }, label = { Text("Remote HTTPS API URL (optional)") }, modifier = Modifier.fillMaxWidth())
                                        Text("A remote backend must implement authenticated deployment, logs, process status, and resource metrics.", color = Muted, fontSize = 12.sp)
                                    }
                                    else -> {
                                        Text("Review & Create", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                        StatusRow("Project", name, Green)
                                        StatusRow("Type", hostingType, Green)
                                        StatusRow("Software/runtime", if (hostingType == "Minecraft") software else runtime, Green)
                                        StatusRow("Version", if (hostingType == "Minecraft") version else "Selected runtime", Green)
                                        StatusRow("RAM request", "${"%.1f".format(ram)} GB", Green)
                                        StatusRow("Execution", mode, Muted)
                                        Text("This starter project saves the setup in the current screen only. It does not deploy until a real local or remote execution adapter is implemented.", color = Color(0xFFFFB74D), fontSize = 12.sp)
                                        Button(onClick = { setupDone = true; notice = "Configuration reviewed. No process started: execution engine is not connected."; page = "Home" }, modifier = Modifier.fillMaxWidth()) { Text("Finish Setup") }
                                    }
                                }
                            }
                        }
                        if (wizardStep < 7) item {
                            Button(onClick = { wizardStep++ }, modifier = Modifier.fillMaxWidth()) {
                                Text("NEXT  →")
                            }
                        }
                    }
                }
                item { Text(notice, color = Muted, fontSize = 12.sp) }
                item { Text("Starter MVP · Local and remote execution engines are not yet connected.", color = Color(0xFF777777), fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun HostCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(
        color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF343434)),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFF17372B), shape = RoundedCornerShape(14.dp)) {
                Icon(icon, null, tint = Green, modifier = Modifier.padding(13.dp).size(28.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(description, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Green)
        }
    }
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF303030)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun StatusRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 13.sp)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SelectRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) Color(0xFF23352D) else Color(0xFF202020),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Green else Color(0xFF363636)),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f))
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = Green)
        }
    }
}
